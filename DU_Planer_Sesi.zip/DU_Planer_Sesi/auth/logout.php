<?php
require_once '../config/conexao.php';
session_destroy();
header('Location: ' . BASE_URL . '/index.php');
exit;
?>