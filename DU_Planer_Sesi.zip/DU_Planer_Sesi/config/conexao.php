<?php
// ============================================
// CONFIGURAÇÃO DE CONEXÃO COM BANCO DE DADOS
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '12345678');
define('DB_NAME', 'planer_sesi');
define('DB_CHARSET', 'utf8mb4');

// Configurações de E-mail
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'seuemail@gmail.com');
define('MAIL_PASS', 'suasenha');
define('MAIL_FROM', 'noreply@planersesi.com');
define('MAIL_FROM_NAME', 'Planer SESI');

// ⚠️ CORRIJA AQUI - coloque o nome correto da sua pasta
define('BASE_URL', 'http://localhost/DU_Planer_Sesi');

// Timezone
date_default_timezone_set('America/Sao_Paulo');

// ============================================
// CONEXÃO PDO
// ============================================
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    die("<div style='background:#ffebee;color:#b71c1c;padding:20px;margin:20px;border-radius:8px;font-family:Arial;'>
        <strong>❌ Erro de conexão com o banco de dados:</strong><br>
        " . $e->getMessage() . "<br><br>
        <strong>Verifique:</strong><br>
        1. O XAMPP está rodando (Apache + MySQL)<br>
        2. O banco 'planer_sesi' foi criado<br>
        3. As credenciais estão corretas
    </div>");
}

// Iniciar sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>