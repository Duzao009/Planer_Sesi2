-- ============================================
-- ATUALIZAÇÃO DO BANCO - Novas colunas para jogos
-- Execute este arquivo se já tiver o banco criado
-- ============================================

USE planer_sesi;

-- Adicionar coluna de ícone personalizado (caso não exista)
ALTER TABLE jogos 
ADD COLUMN IF NOT EXISTS icone VARCHAR(10) DEFAULT '🏆',
ADD COLUMN IF NOT EXISTS cor_primaria VARCHAR(7) DEFAULT '#CC0000',
ADD COLUMN IF NOT EXISTS cor_secundaria VARCHAR(7) DEFAULT '#990000',
ADD COLUMN IF NOT EXISTS criado_por INT NULL,
ADD COLUMN IF NOT EXISTS imagem_url VARCHAR(255) NULL;

-- Atualizar ícones dos jogos existentes
UPDATE jogos SET icone = '⚽' WHERE nome = 'Futsal';
UPDATE jogos SET icone = '🤾' WHERE nome = 'Handebol';
UPDATE jogos SET icone = '🏀' WHERE nome = 'Basquete';
UPDATE jogos SET icone = '🏐' WHERE nome = 'Vôlei';
UPDATE jogos SET icone = '🎾' WHERE nome = 'Beach Tênis';
UPDATE jogos SET icone = '🏖️' WHERE nome = 'Vôlei de Praia';
UPDATE jogos SET icone = '🏐' WHERE nome = 'Futevôlei';