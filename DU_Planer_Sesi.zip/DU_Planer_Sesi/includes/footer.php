<footer class="footer-main">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <div class="footer-logo">
                    <div class="logo-icon">🏆</div>
                    <div class="logo-text">
                        <span class="logo-planer">Planer</span>
                        <span class="logo-sesi">SESI</span>
                    </div>
                </div>
                <p>Sistema de Gerenciamento dos Jogos Escolares SESI 2025</p>
            </div>
            
            <div class="footer-col">
                <h4>Modalidades</h4>
                <ul>
                    <li>⚽ Futsal</li>
                    <li>🤾 Handebol</li>
                    <li>🏀 Basquete</li>
                    <li>🏐 Vôlei</li>
                    <li>🎾 Beach Tênis</li>
                    <li>🏐 Vôlei de Praia</li>
                    <li>⚽ Futevôlei</li>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4>Links Rápidos</h4>
                <ul>
                    <li><a href="<?= BASE_URL ?>/index.php">Início</a></li>
                    <li><a href="<?= BASE_URL ?>/auth/cadastro_aluno.php">Cadastro Aluno</a></li>
                    <li><a href="<?= BASE_URL ?>/auth/cadastro_professor.php">Cadastro Professor</a></li>
                    <li><a href="<?= BASE_URL ?>/auth/login.php">Login</a></li>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4>Contato</h4>
                <p>📧 contato@sesi.com</p>
                <p>📞 (00) 0000-0000</p>
                <p>📍 Sua cidade, Estado</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>© <?= date('Y') ?> Planer SESI - Todos os direitos reservados.</p>
        </div>
    </div>
</footer>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<?php if (isset($extraJS)): ?>
    <?php foreach ($extraJS as $js): ?>
        <script src="<?= BASE_URL ?>/assets/js/<?= $js ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>