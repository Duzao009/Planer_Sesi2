<?php
// ============================================
// HEADER - includes/header.php
// Este arquivo NÃO deve ter DOCTYPE/html
// pois é incluído dentro de páginas já com DOCTYPE
// ============================================

// Garante que as funções estão carregadas
if (!function_exists('isAlunoLogado')) {
    $rootPath = dirname(__DIR__);
    if (!defined('BASE_URL')) {
        require_once $rootPath . '/config/conexao.php';
    }
    require_once $rootPath . '/includes/functions.php';
}
?>
<!-- Header já está inline nas páginas - este arquivo serve só para verificação -->