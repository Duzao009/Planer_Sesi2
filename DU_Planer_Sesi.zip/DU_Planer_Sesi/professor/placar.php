<?php
$pageTitle = 'Gerenciar Placar';
require_once '../config/conexao.php';
require_once '../includes/functions.php';

if (!isProfessorLogado()) redirecionar(BASE_URL . '/auth/login.php?tipo=professor');

$profId = $_SESSION['professor_id'];
$stmt = $pdo->prepare("SELECT * FROM professores WHERE id = ?");
$stmt->execute([$profId]);
$professor = $stmt->fetch();

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jogoId  = (int)($_POST['jogo_id'] ?? 0);
    $placarA = (int)($_POST['placar_a'] ?? 0);
    $placarB = (int)($_POST['placar_b'] ?? 0);
    $timeA   = sanitize($_POST['time_a'] ?? 'Time A');
    $timeB   = sanitize($_POST['time_b'] ?? 'Time B');
    $status  = sanitize($_POST['status'] ?? 'aguardando');
    
    if ($jogoId) {
        $stmt = $pdo->prepare("
            UPDATE placar SET 
                placar_a = ?, placar_b = ?, 
                time_a = ?, time_b = ?,
                status = ?, professor_id = ?
            WHERE jogo_id = ?
        ");
        
        if ($stmt->execute([$placarA, $placarB, $timeA, $timeB, $status, $profId, $jogoId])) {
            $mensagem = 'Placar atualizado com sucesso!';
        }
    }
}

$jogos = getJogos($pdo);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placar - Planer SESI</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/dashboard.css">
</head>
<body>
<?php include '../includes/header.php'; ?>

<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-user">
            <div class="sidebar-avatar">👨‍🏫</div>
            <div class="sidebar-name"><?= htmlspecialchars($professor['nome_completo']) ?></div>
            <div class="sidebar-role">Professor</div>
        </div>
        <nav class="sidebar-menu">
            <a href="dashboard.php" class="sidebar-link"><span class="link-icon">📊</span> Dashboard</a>
            <a href="gerenciar_inscricoes.php" class="sidebar-link"><span class="link-icon">📋</span> Inscrições</a>
            <a href="placar.php" class="sidebar-link active"><span class="link-icon">🏆</span> Placar</a>
            <a href="relatorio.php" class="sidebar-link"><span class="link-icon">📈</span> Relatórios</a>
            <a href="exportar_pdf.php" class="sidebar-link"><span class="link-icon">📄</span> Exportar PDF</a>
            <a href="<?= BASE_URL ?>/auth/logout.php" class="sidebar-link"><span class="link-icon">🚪</span> Sair</a>
        </nav>
    </aside>
    
    <main class="dashboard-content">
        <div class="page-header">
            <div>
                <h1>🏆 Gerenciar Placar</h1>
                <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> › Placar</p>
            </div>
        </div>
        
        <?php if ($mensagem): echo alerta('sucesso', $mensagem); endif; ?>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(380px, 1fr)); gap: 25px;">
            <?php foreach ($jogos as $jogo): ?>
            <div class="placar-editor">
                <div class="placar-editor-header">
                    <span class="placar-editor-title">
                        <?= getIconeJogo($jogo['nome']) ?> <?= htmlspecialchars($jogo['nome']) ?>
                    </span>
                    <select form="form-<?= $jogo['id'] ?>" name="status" 
                            style="background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.4); padding: 4px 8px; border-radius: 6px; font-size: 0.82rem; cursor: pointer;">
                        <option value="aguardando" <?= ($jogo['placar_status'] ?? '') === 'aguardando' ? 'selected' : '' ?>>Aguardando</option>
                        <option value="em_andamento" <?= ($jogo['placar_status'] ?? '') === 'em_andamento' ? 'selected' : '' ?>>Em Andamento</option>
                        <option value="finalizado" <?= ($jogo['placar_status'] ?? '') === 'finalizado' ? 'selected' : '' ?>>Finalizado</option>
                    </select>
                </div>
                
                <form method="POST" id="form-<?= $jogo['id'] ?>">
                    <input type="hidden" name="jogo_id" value="<?= $jogo['id'] ?>">
                    
                    <div class="placar-controls">
                        <!-- Time A -->
                        <div class="placar-control-group">
                            <input type="text" name="time_a" 
                                   value="<?= htmlspecialchars($jogo['time_a'] ?? 'Time A') ?>"
                                   placeholder="Time A"
                                   style="width: 100%; padding: 8px 12px; border: 2px solid #e0e0e0; border-radius: 8px; text-align: center; font-weight: 600; font-size: 0.9rem;">
                            <div class="placar-score-controls">
                                <button type="button" class="btn-score btn-score-minus" 
                                        onclick="alterarPlacar('placar_a_<?= $jogo['id'] ?>', -1)">−</button>
                                <div class="score-display" id="score-a-<?= $jogo['id'] ?>">
                                    <?= $jogo['placar_a'] ?? 0 ?>
                                </div>
                                <input type="hidden" name="placar_a" id="placar_a_<?= $jogo['id'] ?>" 
                                       value="<?= $jogo['placar_a'] ?? 0 ?>">
                                <button type="button" class="btn-score btn-score-plus" 
                                        onclick="alterarPlacar('placar_a_<?= $jogo['id'] ?>', 1)">+</button>
                            </div>
                        </div>
                        
                        <div style="font-size: 1.5rem; font-weight: 900; color: #CC0000; padding: 0 10px;">VS</div>
                        
                        <!-- Time B -->
                        <div class="placar-control-group">
                            <input type="text" name="time_b" 
                                   value="<?= htmlspecialchars($jogo['time_b'] ?? 'Time B') ?>"
                                   placeholder="Time B"
                                   style="width: 100%; padding: 8px 12px; border: 2px solid #e0e0e0; border-radius: 8px; text-align: center; font-weight: 600; font-size: 0.9rem;">
                            <div class="placar-score-controls">
                                <button type="button" class="btn-score btn-score-minus" 
                                        onclick="alterarPlacar('placar_b_<?= $jogo['id'] ?>', -1)">−</button>
                                <div class="score-display" id="score-b-<?= $jogo['id'] ?>">
                                    <?= $jogo['placar_b'] ?? 0 ?>
                                </div>
                                <input type="hidden" name="placar_b" id="placar_b_<?= $jogo['id'] ?>" 
                                       value="<?= $jogo['placar_b'] ?? 0 ?>">
                                <button type="button" class="btn-score btn-score-plus" 
                                        onclick="alterarPlacar('placar_b_<?= $jogo['id'] ?>', 1)">+</button>
                            </div>
                        </div>
                    </div>
                    
                    <div style="padding: 15px; display: flex; gap: 10px;">
                        <button type="submit" class="btn btn-primary" style="flex: 1;">
                            💾 Salvar Placar
                        </button>
                        <button type="button" class="btn btn-secondary" 
                                onclick="resetarPlacar(<?= $jogo['id'] ?>)">
                            🔄 Reset
                        </button>
                    </div>
                </form>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?>
<script>
function alterarPlacar(inputId, delta) {
    const input = document.getElementById(inputId);
    const parts = inputId.split('_');
    const jogoId = parts[parts.length - 1];
    const timeLetra = parts[1]; // 'a' ou 'b'
    
    let valor = parseInt(input.value) + delta;
    if (valor < 0) valor = 0;
    input.value = valor;
    
    document.getElementById('score-' + timeLetra + '-' + jogoId).textContent = valor;
}

function resetarPlacar(jogoId) {
    if (confirm('Resetar placar para 0x0?')) {
        document.getElementById('placar_a_' + jogoId).value = 0;
        document.getElementById('placar_b_' + jogoId).value = 0;
        document.getElementById('score-a-' + jogoId).textContent = 0;
        document.getElementById('score-b-' + jogoId).textContent = 0;
    }
}
</script>
</body>
</html>