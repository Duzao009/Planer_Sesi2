<?php
// ============================================
// ESQUECI MINHA SENHA - auth/esqueci_senha.php
// Etapa 1: informa e-mail -> recebe código
// Etapa 2: digita código + nova senha
// ============================================
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/conexao.php';
require_once ROOT_PATH . '/includes/functions.php';
require_once ROOT_PATH . '/includes/mailer.php';

$tipo = (($_GET['tipo'] ?? $_POST['tipo'] ?? 'aluno') === 'professor') ? 'professor' : 'aluno';
$tabela = $tipo === 'professor' ? 'professores' : 'alunos';
$etapa = !empty($_SESSION['reset_email']) ? 'codigo' : 'email';
if (($_SESSION['reset_tipo'] ?? '') !== $tipo) $etapa = 'email';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validarCsrf();
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'enviar') {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erro = 'Informe um e-mail válido.';
        } else {
            $stmt = $pdo->prepare("SELECT id, nome_completo FROM $tabela WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $usuario = $stmt->fetch();

            if ($usuario) {
                // Limite: 1 código por minuto
                $rec = $pdo->prepare("SELECT COUNT(*) FROM recuperacao_senha WHERE email = ? AND tipo = ? AND criado_em > (NOW() - INTERVAL 1 MINUTE)");
                $rec->execute([$email, $tipo]);
                if ($rec->fetchColumn() > 0) {
                    $erro = 'Aguarde 1 minuto antes de pedir um novo código.';
                } else {
                    $codigo = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                    $pdo->prepare("UPDATE recuperacao_senha SET usado = 1 WHERE email = ? AND tipo = ?")->execute([$email, $tipo]);
                    $pdo->prepare("INSERT INTO recuperacao_senha (email, tipo, codigo_hash, expira_em) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))")
                        ->execute([$email, $tipo, password_hash($codigo, PASSWORD_DEFAULT)]);

                    if (!enviarCodigoRecuperacao($email, $usuario['nome_completo'], $codigo)) {
                        $erro = 'Não foi possível enviar o e-mail. Verifique a configuração de e-mail em config/conexao.php.';
                    }
                }
            }
            if (!$erro) {
                // Mensagem igual para e-mail existente ou não (segurança)
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_tipo'] = $tipo;
                $etapa = 'codigo';
                $sucesso = 'Se o e-mail estiver cadastrado, você receberá um código de 6 dígitos.';
            }
        }
    }

    if ($acao === 'redefinir') {
        $email = $_SESSION['reset_email'] ?? '';
        $codigo = preg_replace('/\D/', '', $_POST['codigo'] ?? '');
        $senha = $_POST['senha'] ?? '';
        $confirma = $_POST['confirma'] ?? '';
        $etapa = 'codigo';

        if (strlen($senha) < 6) {
            $erro = 'A nova senha deve ter pelo menos 6 caracteres.';
        } elseif ($senha !== $confirma) {
            $erro = 'As senhas não conferem.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM recuperacao_senha WHERE email = ? AND tipo = ? AND usado = 0 AND expira_em > NOW() ORDER BY id DESC LIMIT 1");
            $stmt->execute([$email, $tipo]);
            $rec = $stmt->fetch();

            if (!$rec || $rec['tentativas'] >= 5) {
                $erro = 'Código expirado ou inválido. Solicite um novo código.';
            } elseif (!password_verify($codigo, $rec['codigo_hash'])) {
                $pdo->prepare("UPDATE recuperacao_senha SET tentativas = tentativas + 1 WHERE id = ?")->execute([$rec['id']]);
                $erro = 'Código incorreto.';
            } else {
                $pdo->prepare("UPDATE $tabela SET senha = ? WHERE email = ?")
                    ->execute([password_hash($senha, PASSWORD_DEFAULT), $email]);
                $pdo->prepare("UPDATE recuperacao_senha SET usado = 1 WHERE email = ? AND tipo = ?")->execute([$email, $tipo]);
                unset($_SESSION['reset_email'], $_SESSION['reset_tipo']);
                redirecionar(BASE_URL . '/auth/login.php?tipo=' . $tipo . '&senha_alterada=1');
            }
        }
    }

    if ($acao === 'voltar') {
        unset($_SESSION['reset_email'], $_SESSION['reset_tipo']);
        $etapa = 'email';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esqueci minha senha - Planner SESI</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/auth.css">
    <link rel="icon" href="<?= BASE_URL ?>/favicon.png" type="image/png">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/modern.css">
</head>
<body>
<?php include '../includes/header.php'; ?>

<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-header">
            <span class="logo-icon">🔒</span>
            <h1>Recuperar senha</h1>
            <p><?= $tipo === 'professor' ? 'Professor' : 'Aluno' ?></p>
        </div>

        <div class="auth-body">
            <?php if ($erro) echo alerta('erro', $erro); ?>
            <?php if ($sucesso) echo alerta('sucesso', $sucesso); ?>

            <?php if ($etapa === 'email'): ?>
                <p class="subtitle">Digite seu e-mail cadastrado. Enviaremos um código para você criar uma nova senha.</p>
                <form method="POST">
                    <?= csrfField() ?>
                    <input type="hidden" name="tipo" value="<?= $tipo ?>">
                    <input type="hidden" name="acao" value="enviar">
                    <div class="form-group">
                        <label class="form-label">E-mail <span>*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="seuemail@email.com" required autofocus>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg">📧 Enviar código</button>
                </form>
            <?php else: ?>
                <p class="subtitle">Enviamos um código para <strong><?= htmlspecialchars($_SESSION['reset_email'] ?? '') ?></strong>.</p>
                <form method="POST">
                    <?= csrfField() ?>
                    <input type="hidden" name="tipo" value="<?= $tipo ?>">
                    <input type="hidden" name="acao" value="redefinir">
                    <div class="form-group">
                        <label class="form-label">Código de 6 dígitos <span>*</span></label>
                        <input type="text" name="codigo" class="form-control" inputmode="numeric" maxlength="6" pattern="\d{6}" placeholder="000000" required autofocus>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nova senha <span>*</span></label>
                        <input type="password" name="senha" class="form-control" minlength="6" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirmar nova senha <span>*</span></label>
                        <input type="password" name="confirma" class="form-control" minlength="6" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg">✅ Alterar senha</button>
                </form>
                <form method="POST" style="margin-top:10px;">
                    <?= csrfField() ?>
                    <input type="hidden" name="tipo" value="<?= $tipo ?>">
                    <input type="hidden" name="acao" value="voltar">
                    <button type="submit" class="btn btn-block" style="background:none; border:none; color:#CC0000; cursor:pointer;">Não recebeu? Enviar novamente</button>
                </form>
            <?php endif; ?>

            <div class="auth-footer-link" style="margin-top: 20px;">
                <a href="<?= BASE_URL ?>/auth/login.php?tipo=<?= $tipo ?>">← Voltar para o login</a>
            </div>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
</body>
</html>
