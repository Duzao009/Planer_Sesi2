<?php
// Apenas conecta. Nunca cria, renomeia ou altera bancos/tabelas.
function conectarBancoPlanner($host, $porta, $usuario, $senha, $nome = '')
{
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 5,
    ];
    $base = 'mysql:host=' . $host . ';port=' . $porta . ';charset=utf8mb4';
    if ($nome !== '') {
        return [new PDO($base . ';dbname=' . $nome, $usuario, $senha, $options), $nome];
    }

    $servidor = new PDO($base, $usuario, $senha, $options);
    $encontrados = [];
    foreach (['planner_sesi', 'planer_sesi'] as $candidato) {
        $consulta = $servidor->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?');
        $consulta->execute([$candidato]);
        if ($consulta->fetchColumn() !== false) {
            $encontrados[] = $candidato;
        }
    }
    if (count($encontrados) === 0) {
        throw new RuntimeException('BANCO_AUSENTE');
    }
    if (count($encontrados) > 1) {
        throw new RuntimeException('BANCO_AMBIGUO');
    }
    $selecionado = $encontrados[0];
    return [new PDO($base . ';dbname=' . $selecionado, $usuario, $senha, $options), $selecionado];
}