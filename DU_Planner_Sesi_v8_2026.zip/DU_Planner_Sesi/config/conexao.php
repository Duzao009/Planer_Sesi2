<?php
// ============================================
// CONFIGURAÇÃO DE CONEXÃO COM BANCO DE DADOS
// ============================================

$arquivoLocal = __DIR__ . '/local.php';
$configLocal = is_file($arquivoLocal) ? require $arquivoLocal : [];
if (!is_array($configLocal)) {
    $configLocal = [];
}
$GLOBALS['configLocal'] = $configLocal;
function configuracaoPlanner($chave, $padrao = '') {
    global $configLocal;
    $ambiente = getenv($chave);
    return $ambiente !== false ? $ambiente : ($configLocal[$chave] ?? $padrao);
}
define('DB_HOST', configuracaoPlanner('DB_HOST', 'localhost'));
define('DB_USER', configuracaoPlanner('DB_USER', 'root'));
define('DB_PASS', configuracaoPlanner('DB_PASS', ''));
define('DB_PORT', configuracaoPlanner('DB_PORT', '3306'));
define('DB_CHARSET', 'utf8mb4');

// Configurações de E-mail
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
// >>> PREENCHA AQUI: seu Gmail e a "Senha de app" de 16 letras do Google
// (Conta Google > Segurança > Verificação em duas etapas > Senhas de app)
define('MAIL_USER', configuracaoPlanner('MAIL_USER'));
define('MAIL_PASS', configuracaoPlanner('MAIL_PASS'));
define('MAIL_FROM', configuracaoPlanner('MAIL_FROM') ?: MAIL_USER);
define('MAIL_FROM_NAME', 'Planner SESI');

// ============================================
// BASE_URL — detectada automaticamente
// Funciona em qualquer pasta (htdocs/DU_Planner_Sesi, htdocs/planner, etc.)
// ============================================
if (!defined('BASE_URL')) {
    if (PHP_SAPI === 'cli') {
        define('BASE_URL', 'http://localhost');
    } else {
        $protocolo = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host      = $_SERVER['HTTP_HOST'] ?? 'localhost';

        // Descobre a subpasta: pega o caminho do script relativo à raiz do
        // projeto (ex.: auth/login.php) e remove esse final da URL pedida.
        // Comparação sem diferenciar maiúsculas (Windows/XAMPP).
        $raizProjeto = rtrim(str_replace('\\', '/', realpath(dirname(__DIR__)) ?: dirname(__DIR__)), '/');
        $scriptFile  = str_replace('\\', '/', realpath($_SERVER['SCRIPT_FILENAME'] ?? '') ?: ($_SERVER['SCRIPT_FILENAME'] ?? ''));
        $scriptName  = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
        $relativo = '';
        if (stripos($scriptFile, $raizProjeto . '/') === 0) {
            $relativo = substr($scriptFile, strlen($raizProjeto));
        }
        $subPasta = '';
        if ($relativo !== '' && strcasecmp(substr($scriptName, -strlen($relativo)), $relativo) === 0) {
            $subPasta = substr($scriptName, 0, -strlen($relativo));
        } else {
            $subPasta = rtrim(dirname($scriptName), '/');
        }
        $subPasta = rtrim($subPasta, '/');
        define('BASE_URL', $protocolo . '://' . $host . $subPasta);
    }
}

// Timezone
date_default_timezone_set('America/Sao_Paulo');

// ============================================
// CONEXÃO PDO
// ============================================
require_once __DIR__ . '/banco.php';

// Tenta conectar. Se o usuário não configurou senha (sem config/local.php e
// sem variável DB_PASS), testa automaticamente as senhas mais comuns do
// MySQL/XAMPP. Se nada funcionar, abre o assistente instalar.php.
function tentarConexaoPlanner() {
    $senhaDefinida = getenv('DB_PASS') !== false || array_key_exists('DB_PASS', $GLOBALS['configLocal'] ?? []);
    $senhas = $senhaDefinida ? [DB_PASS] : ['', 'root', 'admin', '1234', '12345', '123456', 'usbw', 'mysql', 'password'];
    $hosts = array_unique([DB_HOST, DB_HOST === 'localhost' ? '127.0.0.1' : DB_HOST]);
    $ultimoErro = null;
    foreach ($hosts as $h) {
        foreach ($senhas as $senha) {
            try {
                [$pdo, $nome] = conectarBancoPlanner($h, DB_PORT, DB_USER, $senha, configuracaoPlanner('DB_NAME'));
                return [$pdo, $nome, null];
            } catch (Throwable $e) {
                $ultimoErro = $e;
                $codigo = $e instanceof PDOException ? (int) ($e->errorInfo[1] ?? 0) : 0;
                // Senha certa mas banco ausente/ambíguo: não adianta testar outras.
                if ((!($e instanceof PDOException) && $e instanceof RuntimeException) || $codigo === 1049 || $codigo === 1044) {
                    return [null, null, $e];
                }
                if ($codigo !== 1045 && $codigo !== 1698) {
                    break; // MySQL desligado/porta errada: tenta o próximo host
                }
            }
        }
    }
    return [null, null, $ultimoErro];
}

[$pdo, $nomeBanco, $erroConexao] = tentarConexaoPlanner();
if ($pdo) {
    define('DB_NAME', $nomeBanco);
} else {
    $e = $erroConexao;
    error_log('Falha ao conectar ao banco: ' . ($e ? $e->getMessage() : 'desconhecido'));
    $codigo = $e instanceof PDOException ? (int) ($e->errorInfo[1] ?? 0) : 0;
    $mensagem = 'O MySQL parece estar desligado. Abra o XAMPP Control Panel e clique em Start no MySQL.';
    if ($codigo === 1045 || $codigo === 1698) {
        $mensagem = 'O MySQL recusou o usuário ou a senha.';
    } elseif ($codigo === 1049 || ($e && $e->getMessage() === 'BANCO_AUSENTE')) {
        $mensagem = 'O banco de dados planner_sesi ainda não foi criado.';
    } elseif ($e && $e->getMessage() === 'BANCO_AMBIGUO') {
        $mensagem = 'Existem dois bancos (planner_sesi e planer_sesi). Escolha qual usar.';
    } elseif ($codigo === 1044) {
        $mensagem = 'O usuário do MySQL não tem permissão para acessar este banco.';
    }
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $mensagem . "\n");
        exit(1);
    }
    $linkInstalar = BASE_URL . '/instalar.php';
    $ehApi = strpos(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/api/') !== false;
    http_response_code(503);
    if ($ehApi) {
        header('Content-Type: application/json; charset=utf-8');
        die(json_encode(['erro' => $mensagem]));
    }
    die("<main style='font-family:Arial,sans-serif;max-width:620px;margin:80px auto;padding:24px'><h1>Não foi possível conectar ao banco</h1><p>" . htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') . "</p><p><a href='" . htmlspecialchars($linkInstalar, ENT_QUOTES, 'UTF-8') . "' style='display:inline-block;background:#c8102e;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;font-weight:bold'>Resolver agora (assistente de configuração)</a></p><p style='color:#666;font-size:14px'>O assistente testa a senha do MySQL, salva a configuração e cria o banco automaticamente se ele não existir. Seus cadastros não são apagados.</p></main>");
}

// Iniciar sessão com cookie protegido
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
?>