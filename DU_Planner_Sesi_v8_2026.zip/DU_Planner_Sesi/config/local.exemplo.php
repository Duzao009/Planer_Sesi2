<?php
// Se necessário, copie para local.php nesta mesma pasta.
// Não compartilhe local.php preenchido: ele contém suas credenciais.
return [
    'DB_HOST' => 'localhost',
    'DB_PORT' => '3306',
    'DB_USER' => 'root',
    'DB_PASS' => '', // XAMPP padrão: sem senha. Se alterou, informe a senha real.
    'DB_NAME' => '', // Vazio: detecta o único banco planner_sesi ou planer_sesi.
    'MAIL_USER' => '',
    'MAIL_PASS' => '', // Senha de app do Google, não a senha normal da conta.
    'MAIL_FROM' => '',
];