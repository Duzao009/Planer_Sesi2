-- ============================================
-- ATUALIZAÇÃO DO BANCO - Novas colunas para jogos
-- Execute este arquivo se já tiver o banco criado
-- ============================================

SET NAMES utf8mb4;

-- Selecione primeiro o banco existente no phpMyAdmin.
-- Sem USE para preservar compatibilidade com o nome antigo do banco.

-- Adicionar coluna de ícone personalizado (caso não exista)
ALTER TABLE jogos 
ADD COLUMN IF NOT EXISTS icone VARCHAR(32) DEFAULT 'esporte',
ADD COLUMN IF NOT EXISTS cor_primaria VARCHAR(7) DEFAULT '#CC0000',
ADD COLUMN IF NOT EXISTS cor_secundaria VARCHAR(7) DEFAULT '#990000',
ADD COLUMN IF NOT EXISTS criado_por INT NULL,
ADD COLUMN IF NOT EXISTS imagem_url VARCHAR(255) NULL;

-- Atualizar ícones dos jogos existentes
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Futsal';
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Handebol';
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Basquete';
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Vôlei';
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Vôlei de Praia';
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Futevôlei';

-- Corrigir o nome da modalidade em bancos de versões anteriores
UPDATE jogos
SET nome = 'Beach Tennis',
    descricao = REPLACE(REPLACE(descricao, 'Beat Tênis', 'Beach Tennis'), 'Beach Tênis', 'Beach Tennis'),
    local = REPLACE(REPLACE(local, 'Beat Tênis', 'Beach Tennis'), 'Beach Tênis', 'Beach Tennis')
WHERE LOWER(nome) IN ('beat tênis', 'beat tenis', 'beach tênis', 'beach tenis');
UPDATE jogos SET icone = 'esporte' WHERE nome = 'Beach Tennis';
-- Garanta apenas um placar por modalidade (execute uma vez em bancos antigos):
-- ALTER TABLE placar ADD UNIQUE KEY unique_placar_jogo (jogo_id);


-- Recuperação de senha por código no e-mail
CREATE TABLE IF NOT EXISTS recuperacao_senha (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    tipo ENUM('aluno', 'professor') NOT NULL,
    codigo_hash VARCHAR(255) NOT NULL,
    tentativas INT DEFAULT 0,
    usado TINYINT(1) DEFAULT 0,
    expira_em DATETIME NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_tipo (email, tipo)
);
