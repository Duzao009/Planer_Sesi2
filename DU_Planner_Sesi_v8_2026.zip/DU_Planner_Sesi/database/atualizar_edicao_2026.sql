-- PLANNER SESI - atualização da edição para 2026
-- Faça backup e selecione o banco usado pelo sistema no phpMyAdmin.
-- Sem USE: funciona também quando DB_NAME aponta para um banco existente.
-- Reaplicável; preserva cadastros, inscrições, senhas e datas pessoais.

SET NAMES utf8mb4;
SET @ano_edicao = 2026;
SET @ano_anterior = @ano_edicao - 1;
SET @marca_anterior = CONCAT('Pla', 'ner');

START TRANSACTION;

UPDATE jogos
SET data_inicio = CASE
        WHEN YEAR(data_inicio) = @ano_anterior
        THEN DATE_ADD(data_inicio, INTERVAL 1 YEAR)
        ELSE data_inicio END,
    data_fim = CASE
        WHEN YEAR(data_fim) = @ano_anterior
        THEN DATE_ADD(data_fim, INTERVAL 1 YEAR)
        ELSE data_fim END,
    nome = REPLACE(REPLACE(REPLACE(
        REPLACE(BINARY nome, BINARY CAST(@ano_anterior AS CHAR), BINARY CAST(@ano_edicao AS CHAR)),
        UPPER(@marca_anterior), 'PLANNER'), @marca_anterior, 'Planner'),
        LOWER(@marca_anterior), 'planner'),
    descricao = REPLACE(REPLACE(REPLACE(
        REPLACE(BINARY descricao, BINARY CAST(@ano_anterior AS CHAR), BINARY CAST(@ano_edicao AS CHAR)),
        UPPER(@marca_anterior), 'PLANNER'), @marca_anterior, 'Planner'),
        LOWER(@marca_anterior), 'planner')
WHERE YEAR(data_inicio) = @ano_anterior
   OR YEAR(data_fim) = @ano_anterior
   OR LOCATE(BINARY CAST(@ano_anterior AS CHAR), BINARY nome) > 0
   OR LOCATE(BINARY CAST(@ano_anterior AS CHAR), BINARY descricao) > 0
   OR LOCATE(BINARY LOWER(@marca_anterior), BINARY LOWER(nome)) > 0
   OR LOCATE(BINARY LOWER(@marca_anterior), BINARY LOWER(descricao)) > 0;

COMMIT;

CREATE TABLE IF NOT EXISTS recuperacao_senha (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    tipo ENUM('aluno', 'professor') NOT NULL,
    codigo_hash VARCHAR(255) NOT NULL,
    tentativas INT DEFAULT 0,
    usado TINYINT(1) DEFAULT 0,
    expira_em DATETIME NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_tipo (email, tipo)
);