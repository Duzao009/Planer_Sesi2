-- Selecione o banco existente no phpMyAdmin antes de executar este arquivo.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS recuperacao_senha (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    tipo ENUM('aluno', 'professor') NOT NULL,
    codigo_hash VARCHAR(255) NOT NULL,
    tentativas INT DEFAULT 0,
    usado TINYINT(1) DEFAULT 0,
    expira_em DATETIME NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_tipo (email, tipo)
);
