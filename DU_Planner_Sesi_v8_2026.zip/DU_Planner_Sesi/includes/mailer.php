<?php
// ============================================
// ENVIO DE E-MAIL VIA SMTP (Gmail) - sem bibliotecas externas
// Usa MAIL_HOST, MAIL_PORT, MAIL_USER, MAIL_PASS de config/conexao.php
// ============================================

function smtpEnviar($para, $assunto, $html) {
    if (!MAIL_USER || !MAIL_PASS || MAIL_PASS === 'sua_senha_de_app') {
        error_log('SMTP não configurado em config/conexao.php');
        return false;
    }
    $sock = @stream_socket_client('tcp://' . MAIL_HOST . ':' . MAIL_PORT, $errno, $errstr, 15);
    if (!$sock) { error_log("SMTP conexão falhou: $errstr"); return false; }
    stream_set_timeout($sock, 15);

    $ler = function () use ($sock) {
        $resp = '';
        while (($linha = fgets($sock, 515)) !== false) {
            $resp .= $linha;
            if (isset($linha[3]) && $linha[3] === ' ') break;
        }
        return $resp;
    };
    $cmd = function ($c, $esperado) use ($sock, $ler) {
        if ($c !== null) fwrite($sock, $c . "\r\n");
        $r = $ler();
        if (strpos($r, (string)$esperado) !== 0) {
            throw new Exception('SMTP erro: ' . trim($r));
        }
        return $r;
    };

    try {
        $cmd(null, 220);
        $cmd('EHLO localhost', 250);
        $cmd('STARTTLS', 220);
        if (!stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            throw new Exception('Falha ao iniciar TLS');
        }
        $cmd('EHLO localhost', 250);
        $cmd('AUTH LOGIN', 334);
        $cmd(base64_encode(MAIL_USER), 334);
        $cmd(base64_encode(MAIL_PASS), 235);
        $cmd('MAIL FROM:<' . MAIL_FROM . '>', 250);
        $cmd('RCPT TO:<' . $para . '>', 250);
        $cmd('DATA', 354);

        $headers  = "From: =?UTF-8?B?" . base64_encode(MAIL_FROM_NAME) . "?= <" . MAIL_FROM . ">\r\n";
        $headers .= "To: <$para>\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($assunto) . "?=\r\n";
        $headers .= "Date: " . date('r') . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Content-Transfer-Encoding: base64\r\n";
        $corpo = chunk_split(base64_encode($html));
        $cmd($headers . "\r\n" . $corpo . "\r\n.", 250);
        $cmd('QUIT', 221);
        fclose($sock);
        return true;
    } catch (Exception $e) {
        error_log($e->getMessage());
        fclose($sock);
        return false;
    }
}

function enviarCodigoRecuperacao($email, $nome, $codigo) {
    $html = "
    <html><body style='font-family: Arial, sans-serif; background:#f5f5f5; padding:20px;'>
      <div style='max-width:520px; margin:0 auto; background:#fff; border-radius:10px; overflow:hidden;'>
        <div style='background:#CC0000; padding:24px; text-align:center;'>
          <h1 style='color:#fff; margin:0;'>Planner SESI</h1>
        </div>
        <div style='padding:28px;'>
          <p>Olá, <strong>" . htmlspecialchars($nome) . "</strong>!</p>
          <p>Recebemos um pedido para redefinir sua senha. Use o código abaixo:</p>
          <div style='font-size:32px; letter-spacing:8px; font-weight:bold; text-align:center; background:#f9f9f9; border-left:4px solid #CC0000; padding:16px; margin:20px 0;'>$codigo</div>
          <p>O código vale por <strong>15 minutos</strong>. Se não foi você, ignore este e-mail.</p>
          <p style='color:#CC0000; font-weight:bold;'>Equipe Planner SESI</p>
        </div>
      </div>
    </body></html>";
    return smtpEnviar($email, 'Código para redefinir sua senha - Planner SESI', $html);
}
