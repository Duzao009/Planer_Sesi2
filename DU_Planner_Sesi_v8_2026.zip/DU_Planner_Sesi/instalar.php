<?php
// ============================================
// ASSISTENTE DE CONFIGURAÇÃO DO BANCO - PLANNER SESI
// Testa a senha do MySQL, salva config/local.php e cria o banco
// planner_sesi (a partir de database/banco.sql) somente se ele não existir.
// Nunca apaga bancos nem cadastros.
// ============================================
date_default_timezone_set('America/Sao_Paulo');

// Só pode ser usado no próprio computador do servidor.
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($ip, ['127.0.0.1', '::1', '::ffff:127.0.0.1'], true)) {
    http_response_code(403);
    die("<main style='font-family:Arial,sans-serif;max-width:620px;margin:80px auto'><h1>Acesso negado</h1><p>Abra este assistente no computador que roda o XAMPP, pelo endereço <b>http://localhost/.../instalar.php</b>.</p></main>");
}

require_once __DIR__ . '/config/banco.php';

$arquivoLocal = __DIR__ . '/config/local.php';
$atual = is_file($arquivoLocal) ? (require $arquivoLocal) : [];
if (!is_array($atual)) $atual = [];

$host  = trim($_POST['host'] ?? ($atual['DB_HOST'] ?? 'localhost')) ?: 'localhost';
$porta = trim($_POST['porta'] ?? ($atual['DB_PORT'] ?? '3306')) ?: '3306';
$user  = trim($_POST['usuario'] ?? ($atual['DB_USER'] ?? 'root')) ?: 'root';
$senha = $_POST['senha'] ?? ($atual['DB_PASS'] ?? '');
$bancoEscolhido = $_POST['banco'] ?? '';

$erro = '';
$sucesso = '';
$detalhes = [];
$precisaEscolher = false;

function conectarServidor($host, $porta, $user, $senha) {
    return new PDO('mysql:host=' . $host . ';port=' . $porta . ';charset=utf8mb4', $user, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 5,
    ]);
}

function explicarErro(Throwable $e) {
    $c = $e instanceof PDOException ? (int) ($e->errorInfo[1] ?? $e->getCode()) : 0;
    if ($c === 0 && $e instanceof PDOException) $c = (int) $e->getCode();
    if ($c === 1045 || $c === 1698) return 'Senha ou usuário do MySQL incorretos. Tente outra senha.';
    if ($c === 2002 || $c === 2006 || stripos($e->getMessage(), 'refused') !== false) {
        return 'Não foi possível falar com o MySQL. Abra o XAMPP Control Panel e clique em Start no MySQL. Se a porta for diferente de 3306, altere abaixo.';
    }
    return 'Erro do MySQL: ' . $e->getMessage();
}

// Ao abrir a página, tenta sozinho as senhas mais comuns.
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !is_file($arquivoLocal)) {
    foreach (['', 'root', 'admin', '1234', '12345', '123456', 'usbw', 'mysql', 'password'] as $s) {
        foreach (array_unique([$host, '127.0.0.1']) as $h) {
            try { conectarServidor($h, $porta, $user, $s); $senha = $s; $host = $h; $_POST['auto'] = 1; break 2; }
            catch (Throwable $e) { /* continua */ }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' || !empty($_POST['auto'])) {
    try {
        try {
            $srv = conectarServidor($host, $porta, $user, $senha);
        } catch (PDOException $e1) {
            if ($host !== 'localhost') throw $e1;
            $srv = conectarServidor('127.0.0.1', $porta, $user, $senha); // XAMPP às vezes só aceita TCP
            $host = '127.0.0.1';
        }
        $existentes = [];
        foreach (['planner_sesi', 'planer_sesi'] as $b) {
            $q = $srv->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?');
            $q->execute([$b]);
            if ($q->fetchColumn() !== false) $existentes[] = $b;
        }

        if (count($existentes) === 0) {
            // Instalação nova: cria o banco a partir de database/banco.sql
            $sql = file_get_contents(__DIR__ . '/database/banco.sql');
            $sql = preg_replace('/^\s*--.*$/m', '', $sql);
            foreach (preg_split('/;\s*(\r?\n|$)/', $sql) as $cmd) {
                if (trim($cmd) !== '') $srv->exec($cmd);
            }
            $detalhes[] = 'Banco planner_sesi criado com as tabelas e os jogos iniciais.';
            $nomeBanco = 'planner_sesi';
        } elseif (count($existentes) === 1) {
            $nomeBanco = $existentes[0];
            $detalhes[] = 'Banco existente encontrado: ' . $nomeBanco . ' (seus cadastros foram mantidos).';
        } elseif (in_array($bancoEscolhido, $existentes, true)) {
            $nomeBanco = $bancoEscolhido;
            $detalhes[] = 'Banco escolhido: ' . $nomeBanco . '.';
        } else {
            $precisaEscolher = true;
            $nomeBanco = '';
        }

        if (!$precisaEscolher) {
            // Garante a tabela de recuperação de senha (não altera dados).
            $srv->exec('USE `' . $nomeBanco . '`');
            $rec = preg_replace('/^\s*--.*$/m', '', file_get_contents(__DIR__ . '/database/recuperacao_senha.sql'));
            foreach (preg_split('/;\s*(\r?\n|$)/', $rec) as $cmd) {
                if (trim($cmd) !== '') $srv->exec($cmd);
            }

            $config = [
                'DB_HOST' => $host,
                'DB_PORT' => $porta,
                'DB_USER' => $user,
                'DB_PASS' => $senha,
                'DB_NAME' => $nomeBanco,
                'MAIL_USER' => $atual['MAIL_USER'] ?? '',
                'MAIL_PASS' => $atual['MAIL_PASS'] ?? '',
                'MAIL_FROM' => $atual['MAIL_FROM'] ?? '',
            ];
            $conteudo = "<?php\n// Gerado pelo assistente instalar.php em " . date('d/m/Y H:i') . ".\n// Não compartilhe este arquivo: ele contém a senha do MySQL.\nreturn " . var_export($config, true) . ";\n";
            if (@file_put_contents($arquivoLocal, $conteudo) === false) {
                throw new RuntimeException('Não consegui salvar config/local.php. Verifique se a pasta não está como somente leitura.');
            }
            $sucesso = 'Tudo certo! O sistema está conectado ao banco.';
        }
    } catch (Throwable $e) {
        $erro = ($e instanceof PDOException) ? explicarErro($e) : $e->getMessage();
    }
}

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Configurar banco - Planner SESI</title>
<style>
    body{font-family:Arial,sans-serif;background:#f4f5f7;margin:0;padding:40px 16px;color:#222}
    .card{max-width:560px;margin:0 auto;background:#fff;border-radius:14px;padding:32px;box-shadow:0 6px 24px rgba(0,0,0,.08)}
    h1{margin:0 0 6px;font-size:24px;color:#c8102e}
    p.sub{margin:0 0 24px;color:#666}
    label{display:block;font-weight:bold;margin:14px 0 6px;font-size:14px}
    input,select{width:100%;padding:11px;border:1px solid #ccc;border-radius:8px;font-size:15px;box-sizing:border-box}
    .row{display:flex;gap:12px}.row>div{flex:1}
    button,.btn{display:inline-block;margin-top:22px;background:#c8102e;color:#fff;border:0;padding:13px 22px;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer;text-decoration:none}
    .ok{background:#e7f6ec;border:1px solid #9bd3ad;color:#1d6b35;padding:14px;border-radius:8px;margin-bottom:16px}
    .err{background:#fdecec;border:1px solid #f1a5a5;color:#9b1c1c;padding:14px;border-radius:8px;margin-bottom:16px}
    small{color:#777}
</style>
</head>
<body>
<div class="card">
    <h1>Configurar banco de dados</h1>
    <p class="sub">Planner SESI — este assistente conecta o sistema ao MySQL do XAMPP.</p>

    <?php if ($sucesso): ?>
        <div class="ok"><b><?= $h($sucesso) ?></b><br><?php foreach ($detalhes as $d) echo $h($d) . '<br>'; ?></div>
        <a class="btn" href="index.php">Abrir o Planner SESI</a>
        <p><small>Para seus amigos usarem o mesmo banco, eles devem acessar pelo seu IP (veja COMO_USAR_COM_AMIGOS.txt).</small></p>
    <?php else: ?>
        <?php if ($erro): ?><div class="err"><?= $h($erro) ?></div><?php endif; ?>
        <form method="post">
            <div class="row">
                <div><label>Servidor</label><input name="host" value="<?= $h($host) ?>"></div>
                <div style="max-width:120px"><label>Porta</label><input name="porta" value="<?= $h($porta) ?>"></div>
            </div>
            <label>Usuário do MySQL</label>
            <input name="usuario" value="<?= $h($user) ?>">
            <label>Senha do MySQL</label>
            <input type="password" name="senha" value="" placeholder="Deixe vazio se não tiver senha (padrão do XAMPP)">
            <small>É a senha do MySQL/phpMyAdmin, não a senha do Windows.</small>
            <?php if ($precisaEscolher): ?>
                <label>Encontrei dois bancos. Qual tem seus cadastros?</label>
                <select name="banco">
                    <option value="planner_sesi">planner_sesi</option>
                    <option value="planer_sesi">planer_sesi</option>
                </select>
            <?php endif; ?>
            <button type="submit">Testar e salvar</button>
        </form>
        <p><small>Esqueceu a senha? No XAMPP, abra C:\xampp\phpMyAdmin\config.inc.php e veja a linha
        <code>$cfg['Servers'][$i]['password']</code>.</small></p>
    <?php endif; ?>
</div>
</body>
</html>
